/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package examen1;

/**
 *
 * @author Eddy Moreira
 */
public class enunciado1 {
   
    public String aTap (String original , String matriz ) {

        if (( original == null) || original . equals ("")) {

            return original ;

        }

        String puntos = "";

        for (int i = 0; i < original . length (); i ++) {

            String letra = "" + original . charAt (i );
    
            switch (letra) {
        case "K":
            letra = "C";
            break;
        case " N":
            letra = "N";
            break;
    }

            int n = -1, m = -1;

            if ( matriz.contains(letra)) {

                n = matriz . indexOf ( letra ) / 5;
                m = matriz . indexOf ( letra ) - n * 5;
    }
    
            if (n >= 0 && n >= 0) {
    
                for (int j = 0; j <= n; j ++) {
    
                    puntos = puntos + ".";

                }

                puntos = puntos + " ";

                for (int j = 0; j <= m; j ++) {

                    puntos = puntos + ".";

                }

            }

            puntos = puntos + " ";

        }


        if ( puntos . length () > 0) {

            puntos = puntos .substring(0 , puntos . length () - 1);

        }

        return puntos ;

}
}
   
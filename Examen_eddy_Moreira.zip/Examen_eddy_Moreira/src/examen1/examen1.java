/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package examen1;

/**
 *
 * @author Eddy Moreira Cruz
 */
public class examen1 {

   
    public static void main(String[] args) {
        enunciado1 oenunciado1=new enunciado1();
        String aTap = oenunciado1.aTap(null, null);
        AdminPalabras oAdminPalabras = null;
        int ContarPalabrasPosibles; 
        
    }
    
    
    
}
